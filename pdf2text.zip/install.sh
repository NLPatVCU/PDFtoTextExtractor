sudo apt install tesseract-ocr
sudo apt install libtesseract-dev
python -m venv venv
source venv/bin/activate
pip install -r requirments.txt